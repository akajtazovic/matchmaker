// package
package main

//imports
import (
	"fmt"
	"math"
	"strconv"
)

// constants

const DESIREONE = 4
const DESIRETWO = 1
const DESIRETHREE = 5
const DESIREFOUR = 2
const DESIREFIVE = 3
const WEIGHTONE = 1
const WEIGHTTWO = 2
const WEIGHTTHREE = 3
const COMPATBEST = 89
const COMPATMIDDLE = 75
const COMPATWORST = 70

// validate function: validates the user input and prints an error message if input is incorrect.
func validate(x string, y string) int {
	i, err := strconv.Atoi(x)
	if err != nil {
		fmt.Println("Error must be an integer")
		fmt.Println(y)
		fmt.Scanln(&x)
		i = validate(x, y)
	}
	if (i != 1) && (i != 2) && (i != 3) && (i != 4) && (i != 5) {
		fmt.Println("ERROR must be a number 1-5")
		fmt.Println(y)
		fmt.Scanln(&x)
		i = validate(x, y)
	}
	return i
}

// main
func main() {
	fmt.Println("Welcome to The Matchmaker Program <3.")
	fmt.Println(" ")
	fmt.Println("Let's see if we are soulmates!")
	fmt.Println("Read the question, then enter a number from one to five.")
	fmt.Println("one being completely disagree and five being completely agree.")
	fmt.Println("")

	y1 := "My favorite color is Pink."
	fmt.Println(y1)
	var first string
	fmt.Scanln(&first)
	firsti := validate(first, y1)
	proxione := DESIREONE - firsti
	proxone := int(math.Abs(float64(proxione)))
	sum1 := proxone * WEIGHTTHREE
	fmt.Println(" ")
	fmt.Println("SUMMARY:")
	fmt.Println("Compatibility Score: ", proxone)
	fmt.Println("Weighted Score : ", sum1)
	fmt.Println(" ")

	y2 := "I hate Water."
	var second string
	fmt.Scanln(&second)
	secondi := validate(second, y2)
	proxitwo := DESIRETWO - secondi
	proxtwo := int(math.Abs(float64(proxitwo)))
	sum2 := proxtwo * WEIGHTTHREE
	fmt.Println(" ")
	fmt.Println("Compatibility Score: ", proxtwo)
	fmt.Println("Weighted Score : ", sum2)
	fmt.Println(" ")

	y3 := "I think the two-party political system is bad."
	var third string
	fmt.Scanln(&third)
	thirdi := validate(third, y3)
	proxithree := DESIRETHREE - thirdi
	proxthree := int(math.Abs(float64(proxithree)))
	sum3 := proxthree * WEIGHTTHREE
	fmt.Println(" ")
	fmt.Println("SUMMARY:")
	fmt.Println("Compatibility Score: ", proxthree)
	fmt.Println("Weighted Score : ", sum3)
	fmt.Println(" ")

	y4 := "I love math!"
	var fourth string
	fmt.Scanln(&fourth)
	fourthi := validate(fourth, y4)
	proxifour := DESIREFOUR - fourthi
	proxfour := int(math.Abs(float64(proxifour)))
	sum4 := proxfour * WEIGHTTWO
	fmt.Println(" ")
	fmt.Println("SUMMARY:")
	fmt.Println("Compatibility Score: ", proxfour)
	fmt.Println("Weighted Score : ", sum4)
	fmt.Println(" ")

	y5 := "Programming is fun."
	var fifth string
	fmt.Scanln(&fifth)
	fifthi := validate(fifth, y5)
	proxifive := DESIREFIVE - fifthi
	proxfive := int(math.Abs(float64(proxifive)))
	sum5 := proxfive * WEIGHTONE
	fmt.Println(" ")
	fmt.Println("SUMMARY:")
	fmt.Println("Compatibility Score: ", proxfive)
	fmt.Println("Weighted Score : ", sum5)
	fmt.Println(" ")

	compatibility := sum1 + sum2 + sum3 + sum4 + sum5
	finalcompatscore := 100 - compatibility
	fmt.Printf("Final Compatibility Score: %d %% ", finalcompatscore)

	if finalcompatscore >= COMPATBEST {
		fmt.Println("")
		fmt.Println("Wow, we really are soulmates.")

	} else if finalcompatscore >= COMPATMIDDLE && finalcompatscore < COMPATBEST {

		fmt.Println("")
		fmt.Println("Eh, we'd get along somewhat")

	} else if finalcompatscore < COMPATMIDDLE && finalcompatscore <= COMPATWORST {

		fmt.Println("")
		fmt.Println("Ugh, you can't sit with us.")
	}
}
